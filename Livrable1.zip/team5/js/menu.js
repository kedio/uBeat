$('#menu-button').click(function() {
    $('.wrapper').toggleClass('menu-visible');
});